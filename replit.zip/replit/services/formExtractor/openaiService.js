const OpenAI = require('openai');
const { v4: uuidv4 } = require('uuid');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

const MAX_PAGES_PER_BATCH = 3;

const SYSTEM_PROMPT = `You are a form structure analyzer. Analyze the provided form image(s) and extract the complete structure.

TASK: Identify all form fields and classify them into these component types ONLY:
- Signature: Signature lines or boxes
- Multi-Select: Checkboxes (multiple can be selected)
- File Upload: File/document attachment areas
- Short Input: Single-line text fields
- Sections: Section dividers or headers within the form
- Dropdown: Select/dropdown menus
- Radio Select: Radio buttons (single selection)
- Table: Tabular data entry with columns and rows
- Title: Bold text, headings that introduce/group fields
- Long Input: Multi-line text areas

DOCUMENT STRUCTURE - FLAT (NO SUBSECTIONS):
1. **SECTIONS**: Major sections with headers (highlighted/shaded backgrounds like "III. COVERAGE", "IV. EXPOSURES")
2. **FIELDS**: All items within a section are FIELDS (including titles like "HOSPITALS", "Self-Insured Retention (SIR):")

CRITICAL RULES:
1. **PRESERVE EXACT TEXT**: Copy all labels and titles EXACTLY as they appear in the document. Do NOT rephrase, shorten, summarize, or modify any text.
2. **EXCLUDE SERIAL NUMBERS**: Remove leading numbering/lettering from labels:
   - "A. Does the applicant..." → "Does the applicant..."
   - "III. COVERAGE" → "COVERAGE"
   - "1. Full Name" → "Full Name"
   Do NOT include: I., II., III., A., B., 1., 2., (a), (b), etc. at the start.
3. **SKIP INSTRUCTION TEXT**: Do NOT include instruction paragraphs like "Please complete the data below...", guidance text, or any non-input descriptive text. Only capture actual INPUT FIELDS.
4. **BOLD TEXT = Title component**: Bold/emphasized text that labels a group (like "HOSPITALS", "Self-Insured Retention (SIR):") should be a Title component
5. Extract ALL visible options for Multi-Select, Radio Select, and Dropdown
6. For Table: extract column headers and COUNT the rows (rowCount)
7. Mark fields as required if they show asterisks (*) or "required"
8. Maintain top-to-bottom, left-to-right ordering
9. **ONLY INPUT FIELDS**: Only capture fields that have actual input areas (text boxes, checkboxes, dropdowns, signature lines, tables).

RESPOND WITH ONLY VALID JSON in this exact format:
{
  "formTitle": "Form Title Here",
  "sections": [
    {
      "id": "section_1",
      "title": "COVERAGE",
      "order": 1,
      "fields": [
        {
          "id": "field_1",
          "component": "Radio Select",
          "label": "Does the applicant want to change the current insurance structure:",
          "required": false,
          "order": 1,
          "options": ["Yes", "No"]
        }
      ]
    }
  ]
}

FIELD PROPERTIES:
- For Multi-Select, Radio Select, Dropdown: add "options": ["Option 1", "Option 2"]
- For Table: add "columns" (header row) and "rowCount" (number of rows)
- For Title: just include the "label" with the title/heading text`;

function generateId(prefix = '') {
  const shortId = uuidv4().split('-')[0];
  return prefix ? `${prefix}_${shortId}` : shortId;
}

function extractJsonFromText(text) {
  const jsonBlockMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (jsonBlockMatch) return jsonBlockMatch[1].trim();
  const jsonObjectMatch = text.match(/\{[\s\S]*\}/);
  if (jsonObjectMatch) return jsonObjectMatch[0];
  return text;
}

function safeJsonParse(str) {
  try {
    return { success: true, data: JSON.parse(str) };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function extractFormStructure(images) {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error('OPENAI_API_KEY is not configured');
  }

  if (!images || images.length === 0) {
    throw new Error('No images provided for analysis');
  }

  try {
    if (images.length <= MAX_PAGES_PER_BATCH) {
      return await processImageBatch(images, 1, images.length);
    }

    console.log(`Processing ${images.length} pages in batches of ${MAX_PAGES_PER_BATCH}...`);

    const batchResults = [];
    for (let i = 0; i < images.length; i += MAX_PAGES_PER_BATCH) {
      const batch = images.slice(i, i + MAX_PAGES_PER_BATCH);
      const startPage = i + 1;
      console.log(`Processing pages ${startPage}-${Math.min(i + MAX_PAGES_PER_BATCH, images.length)}...`);
      const result = await processImageBatch(batch, startPage, images.length);
      batchResults.push(result);
    }

    return combineResults(batchResults);
  } catch (error) {
    if (error.code === 'insufficient_quota') {
      throw new Error('OpenAI API quota exceeded. Please check your billing.');
    }
    if (error.code === 'invalid_api_key') {
      throw new Error('Invalid OpenAI API key');
    }
    throw error;
  }
}

async function processImageBatch(images, startPage, totalPages) {
  const content = [
    {
      type: 'text',
      text: totalPages > images.length
        ? `Analyze pages ${startPage} to ${startPage + images.length - 1} of ${totalPages} of this form. Extract all form fields visible on these pages.`
        : 'Analyze this form and extract its complete structure.'
    }
  ];

  for (const img of images) {
    content.push({
      type: 'image_url',
      image_url: {
        url: `data:${img.mimeType};base64,${img.base64}`,
        detail: 'high'
      }
    });
  }

  const response = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user', content }
    ],
    max_tokens: 4096,
    temperature: 0.1
  });

  const responseContent = response.choices[0]?.message?.content;

  if (!responseContent) {
    throw new Error('Empty response from GPT-4o');
  }

  if (responseContent.toLowerCase().includes("i'm sorry") ||
      responseContent.toLowerCase().includes("i cannot") ||
      responseContent.toLowerCase().includes("i can't")) {
    throw new Error('The AI could not process this document. Please try with a clearer image.');
  }

  const jsonString = extractJsonFromText(responseContent);
  const parseResult = safeJsonParse(jsonString);

  if (!parseResult.success) {
    console.error('Failed to parse GPT-4o response:', responseContent);
    throw new Error('Invalid JSON response from AI. Please try again.');
  }

  return normalizeFormStructure(parseResult.data);
}

function combineResults(results) {
  if (results.length === 0) return { formTitle: 'Untitled Form', sections: [] };
  if (results.length === 1) return results[0];

  const formTitle = results[0].formTitle || 'Untitled Form';
  let sectionOrder = 0;
  const allSections = [];

  for (const result of results) {
    for (const section of result.sections || []) {
      sectionOrder++;
      allSections.push({
        ...section,
        id: `section_${sectionOrder}`,
        order: sectionOrder,
        fields: (section.fields || []).map((field, idx) => ({
          ...field,
          id: `field_${sectionOrder}_${idx + 1}`
        }))
      });
    }
  }

  return { formTitle, sections: allSections };
}

function normalizeField(field, fieldIndex) {
  const normalizedField = {
    id: field.id || generateId('field'),
    component: normalizeComponentType(field.component || field.type),
    label: field.label || `Field ${fieldIndex + 1}`,
    required: Boolean(field.required),
    order: field.order || fieldIndex + 1
  };

  if (['Multi-Select', 'Radio Select', 'Dropdown'].includes(normalizedField.component)) {
    normalizedField.options = field.options || [];
  }

  if (normalizedField.component === 'Table') {
    normalizedField.columns = field.columns || [];
    normalizedField.rowCount = field.rowCount || 0;
  }

  return normalizedField;
}

function normalizeFormStructure(data) {
  const formTitle = data.formTitle || 'Untitled Form';
  const sections = data.sections || [];

  const normalizedSections = sections.map((section, sectionIndex) => ({
    id: section.id || generateId('section'),
    title: section.title || `Section ${sectionIndex + 1}`,
    order: section.order || sectionIndex + 1,
    fields: (section.fields || []).map((field, fieldIndex) => normalizeField(field, fieldIndex))
  }));

  return { formTitle, sections: normalizedSections };
}

function normalizeComponentType(type) {
  if (!type) return 'Short Input';

  const typeMap = {
    'signature': 'Signature',
    'multi-select': 'Multi-Select',
    'multiselect': 'Multi-Select',
    'checkbox': 'Multi-Select',
    'checkboxes': 'Multi-Select',
    'file upload': 'File Upload',
    'fileupload': 'File Upload',
    'file': 'File Upload',
    'short input': 'Short Input',
    'shortinput': 'Short Input',
    'text': 'Short Input',
    'input': 'Short Input',
    'sections': 'Sections',
    'section': 'Sections',
    'dropdown': 'Dropdown',
    'select': 'Dropdown',
    'radio select': 'Radio Select',
    'radioselect': 'Radio Select',
    'radio': 'Radio Select',
    'table': 'Table',
    'title': 'Title',
    'heading': 'Title',
    'long input': 'Long Input',
    'longinput': 'Long Input',
    'textarea': 'Long Input'
  };

  const normalized = typeMap[type.toLowerCase()];
  if (normalized) return normalized;

  const validTypes = [
    'Signature', 'Multi-Select', 'File Upload', 'Short Input',
    'Sections', 'Dropdown', 'Radio Select', 'Table', 'Title', 'Long Input'
  ];

  if (validTypes.includes(type)) return type;
  return 'Short Input';
}

module.exports = { extractFormStructure };
