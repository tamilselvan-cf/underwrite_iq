const path = require('path');
const fs = require('fs').promises;
const sharp = require('sharp');
const { v4: uuidv4 } = require('uuid');

let pdfPoppler;
try {
  pdfPoppler = require('pdf-poppler');
} catch (error) {
  console.warn('pdf-poppler not available');
}

const UPLOADS_DIR = path.join(__dirname, '../../uploads');
const TEMP_DIR = path.join(__dirname, '../../uploads/temp');

async function ensureDirectory(dirPath) {
  try {
    await fs.mkdir(dirPath, { recursive: true });
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
  }
}

async function fileToBase64(filePath) {
  const fileBuffer = await fs.readFile(filePath);
  return fileBuffer.toString('base64');
}

async function cleanupFiles(filePaths) {
  for (const filePath of filePaths) {
    try {
      await fs.unlink(filePath);
    } catch (error) {
      // Ignore cleanup errors
    }
  }
}

function getFileExtension(filename) {
  return path.extname(filename).toLowerCase().slice(1);
}

function isSupportedFileType(filename) {
  const supportedTypes = ['pdf', 'jpg', 'jpeg', 'png'];
  return supportedTypes.includes(getFileExtension(filename));
}

async function convertPdfToImages(pdfPath, outputDir) {
  if (!pdfPoppler) {
    throw new Error('PDF processing not available. Please install poppler.');
  }

  await ensureDirectory(outputDir);
  const baseName = path.basename(pdfPath, '.pdf');

  const options = {
    format: 'png',
    out_dir: outputDir,
    out_prefix: baseName,
    page: null
  };

  await pdfPoppler.convert(pdfPath, options);

  const files = await fs.readdir(outputDir);
  const imageFiles = files
    .filter(f => f.startsWith(baseName) && f.endsWith('.png'))
    .sort((a, b) => {
      const numA = parseInt(a.match(/-(\d+)\.png$/)?.[1] || '0');
      const numB = parseInt(b.match(/-(\d+)\.png$/)?.[1] || '0');
      return numA - numB;
    });

  const images = [];
  for (let i = 0; i < imageFiles.length; i++) {
    const imagePath = path.join(outputDir, imageFiles[i]);
    const base64 = await fileToBase64(imagePath);
    images.push({
      page: i + 1,
      base64,
      path: imagePath,
      mimeType: 'image/png'
    });
  }

  return images;
}

async function processImage(imagePath, outputDir) {
  const baseName = path.basename(imagePath, path.extname(imagePath));
  const outputPath = path.join(outputDir, `${baseName}_processed.png`);

  await sharp(imagePath)
    .png({ quality: 90 })
    .resize({
      width: 2000,
      height: 2000,
      fit: 'inside',
      withoutEnlargement: true
    })
    .toFile(outputPath);

  const base64 = await fileToBase64(outputPath);

  return [{
    page: 1,
    base64,
    path: outputPath,
    mimeType: 'image/png'
  }];
}

async function processFile(file) {
  const extension = getFileExtension(file.originalname);
  const sessionId = uuidv4();
  const tempDir = path.join(TEMP_DIR, sessionId);

  await ensureDirectory(tempDir);
  const filesToCleanup = [];

  try {
    let images = [];

    switch (extension) {
      case 'pdf':
        images = await convertPdfToImages(file.path, tempDir);
        break;
      case 'jpg':
      case 'jpeg':
      case 'png':
        images = await processImage(file.path, tempDir);
        break;
      default:
        throw new Error(`Unsupported file type: ${extension}`);
    }

    images.forEach(img => {
      if (img.path) filesToCleanup.push(img.path);
    });
    filesToCleanup.push(file.path);

    return images.map(img => ({
      page: img.page,
      base64: img.base64,
      mimeType: img.mimeType
    }));
  } finally {
    await cleanupFiles(filesToCleanup);
    try {
      await fs.rmdir(tempDir);
    } catch (e) {}
  }
}

module.exports = {
  processFile,
  isSupportedFileType,
  UPLOADS_DIR,
  ensureDirectory
};
