/**
 * Form Extractor API - Replit Version
 *
 * If you have an EXISTING Express app, just add this to your main file:
 *
 *   const formExtractorRoutes = require('./routes/formExtractor');
 *   app.use('/api', formExtractorRoutes);
 *
 * If this IS your main app, use the code below:
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const formExtractorRoutes = require('./routes/formExtractor');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api', formExtractorRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error handling
app.use((err, req, res, next) => {
  console.error('Error:', err.message);

  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({
      success: false,
      error: 'File size exceeds the maximum allowed limit'
    });
  }

  if (err.message === 'Invalid file type') {
    return res.status(400).json({
      success: false,
      error: 'Invalid file type. Allowed types: PDF, JPG, PNG'
    });
  }

  res.status(500).json({
    success: false,
    error: process.env.NODE_ENV === 'development' ? err.message : 'Internal server error'
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, error: 'Endpoint not found' });
});

// Start server - bind to 0.0.0.0 for Replit
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Form Extractor API running on port ${PORT}`);
  console.log(`Health check: /health`);
  console.log(`Extract form: POST /api/extract-form`);
});

module.exports = app;
