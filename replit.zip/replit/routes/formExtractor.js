const express = require('express');
const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const { processFile, isSupportedFileType, UPLOADS_DIR, ensureDirectory } = require('../services/formExtractor/fileProcessor');
const { extractFormStructure } = require('../services/formExtractor/openaiService');

const router = express.Router();

// Configure multer storage
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    await ensureDirectory(UPLOADS_DIR);
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${uuidv4()}-${file.originalname}`;
    cb(null, uniqueName);
  }
});

// File filter
const fileFilter = (req, file, cb) => {
  if (isSupportedFileType(file.originalname)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type'), false);
  }
};

// Configure multer
const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024
  }
});

/**
 * POST /api/extract-form
 * Extract form structure from uploaded document
 */
router.post('/extract-form', (req, res, next) => {
  const uploadHandler = upload.any();

  uploadHandler(req, res, (err) => {
    if (err) return next(err);
    req.file = req.files && req.files[0];
    handleFormExtraction(req, res, next);
  });
});

async function handleFormExtraction(req, res, next) {
  const startTime = Date.now();

  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        error: 'No file uploaded. Please upload a PDF, JPG, or PNG file.'
      });
    }

    console.log(`Processing file: ${req.file.originalname} (${req.file.size} bytes)`);

    const images = await processFile(req.file);
    console.log(`Converted to ${images.length} image(s), sending to GPT-4o...`);

    const formStructure = await extractFormStructure(images);

    const processingTime = Date.now() - startTime;
    console.log(`Form extraction completed in ${processingTime}ms`);

    res.json({
      success: true,
      data: formStructure,
      meta: {
        originalFilename: req.file.originalname,
        fileSize: req.file.size,
        pagesProcessed: images.length,
        processingTimeMs: processingTime
      }
    });
  } catch (error) {
    console.error('Form extraction error:', error);
    next(error);
  }
}

/**
 * GET /api/extract-form/supported-types
 */
router.get('/extract-form/supported-types', (req, res) => {
  res.json({
    success: true,
    data: {
      supportedTypes: ['pdf', 'jpg', 'jpeg', 'png'],
      maxFileSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024,
      components: [
        'Signature',
        'Multi-Select',
        'File Upload',
        'Short Input',
        'Sections',
        'Dropdown',
        'Radio Select',
        'Table',
        'Title',
        'Long Input'
      ]
    }
  });
});

module.exports = router;
