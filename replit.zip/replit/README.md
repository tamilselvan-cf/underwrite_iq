# Form Extractor API - Replit Setup

## Quick Setup

### 1. Add to your existing Replit project

Copy these folders/files to your Replit project:
```
├── services/
│   └── formExtractor/
│       ├── openaiService.js
│       └── fileProcessor.js
├── routes/
│   └── formExtractor.js
└── uploads/           (create empty folder)
```

### 2. Install dependencies

In Replit Shell, run:
```bash
npm install openai multer sharp uuid pdf-poppler
```

### 3. Add Environment Variables (Secrets)

In Replit, go to **Secrets** (lock icon) and add:
- `OPENAI_API_KEY` = your OpenAI API key
- `MAX_FILE_SIZE` = 10485760 (optional, 10MB default)

### 4. Integrate with your existing Express app

Add this to your main file (index.js or server.js):

```javascript
const formExtractorRoutes = require('./routes/formExtractor');
app.use('/api', formExtractorRoutes);
```

### 5. Install Poppler (for PDF support)

In Replit Shell:
```bash
# For Nix-based Replit
nix-env -iA nixpkgs.poppler_utils
```

Or add to your `replit.nix`:
```nix
{ pkgs }: {
  deps = [
    pkgs.nodejs-18_x
    pkgs.poppler_utils
  ];
}
```

## API Endpoints

### POST /api/extract-form
Upload a PDF, JPG, or PNG file to extract form structure.

**Request:**
- Content-Type: multipart/form-data
- Body: file (any field name works)

**Response:**
```json
{
  "success": true,
  "data": {
    "formTitle": "Application Form",
    "sections": [
      {
        "id": "section_1",
        "title": "COVERAGE",
        "order": 1,
        "fields": [
          {
            "id": "field_1_1",
            "component": "Radio Select",
            "label": "Does the applicant want to change...",
            "required": false,
            "order": 1,
            "options": ["Yes", "No"]
          }
        ]
      }
    ]
  },
  "meta": {
    "originalFilename": "form.pdf",
    "fileSize": 123456,
    "pagesProcessed": 3,
    "processingTimeMs": 5000
  }
}
```

### GET /api/extract-form/supported-types
Get list of supported file types and components.

## Component Types

| Component | Description | Extra Properties |
|-----------|-------------|------------------|
| Signature | Signature boxes/lines | - |
| Multi-Select | Checkboxes | `options: []` |
| File Upload | File attachment areas | - |
| Short Input | Single-line text | - |
| Sections | Section dividers | - |
| Dropdown | Select menus | `options: []` |
| Radio Select | Radio buttons | `options: []` |
| Table | Data tables | `columns: []`, `rowCount` |
| Title | Headings | - |
| Long Input | Multi-line text | - |

## Test with cURL

```bash
curl -X POST https://your-replit-url.replit.dev/api/extract-form \
  -F "file=@your-form.pdf"
```
